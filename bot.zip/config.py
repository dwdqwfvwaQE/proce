# Конфигурация системы
BOT_TOKEN = "8364760741:AAF_ZsJzTWtU0S1yBMojyOjH_oYcA9HPhds"  
# Данные для UserBot (получить на my.telegram.org)
USERBOT_API_ID = 36310732  # Ваш API ID
USERBOT_API_HASH = "961309c56e390e0e937b0f333e72e9b4" 
USERBOT_SESSION_FILE = "userbot"  

ADMIN_ID = 8262248895  
# Настройки проверок
WEB_CHECK_MIN_DIFF = 50  
MAX_WAIT_TIME = 300  
